package es.ucm.fdi.ici.c1920.practica4.grupo01;

public class OutputGhosts 
{	
	private boolean run = false;
	
	public void processOutput(GhostsDescription queryDesc)
	{
		
	}

	public boolean isRunning() { return run; }
}
