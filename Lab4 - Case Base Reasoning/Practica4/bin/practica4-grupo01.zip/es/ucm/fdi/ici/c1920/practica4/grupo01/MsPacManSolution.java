package es.ucm.fdi.ici.c1920.practica4.grupo01;

import es.ucm.fdi.ici.c1920.practica4.grupo01.Constants.CASE_TYPE;
import pacman.game.Constants.MOVE;
import ucm.gaia.jcolibri.cbrcore.Attribute;

public class MsPacManSolution implements ucm.gaia.jcolibri.cbrcore.CaseComponent
{
	String id; 
	
	CASE_TYPE type;
	
	Boolean achivementMade;
	Integer totalPoints;
	Boolean dead;
	Float evaluation;
	MOVE moveMade;

	public Attribute getIdAttribute()
	{
		return new Attribute("id", MsPacManDescription.class); 
	}
	
	public void setId(String i) {id = i;}
	
	public CASE_TYPE getCaseType() { return type; }
	public void setCaseType(CASE_TYPE n) { type = n; }
	
	public Boolean getAchivementMade() { return achivementMade; }
	public void setAchivementMade(Boolean n) { achivementMade = n; }
	
	public Integer getTotalPoints() { return totalPoints; }
	public void setTotalPoints(Integer n) { totalPoints = n; }

	public Boolean getDead() { return dead; }
	public void setDead(Boolean n) { dead = n; }

	public Float getEvaluation() { return evaluation; }
	public void setEvaluation(Float n) { evaluation = n; }
	
	public MOVE getMoveMade() { return moveMade; }
	public void setMoveMade(MOVE n) { moveMade = n; }
}
