package es.ucm.fdi.ici.c1920.practica4.grupo01;

import ucm.gaia.jcolibri.method.retrieve.NNretrieval.similarity.StandardGlobalSimilarityFunction;

public class MsPacManGlobalSimilarityFunction extends StandardGlobalSimilarityFunction 
{
    /**
     * Hook method that must be implemented by subclasses returned the global similarity value.
     * @param values of the similarity of the sub-attributes
     * @param weights of the sub-attributes
     * @param numberOfvalues (or sub-attributes) that were obtained (some subattributes may not compute for the similarity).
     * @return a value between [0..1]
     */

	public double computeSimilarity(double[] values, double[] weights, int ivalue)
	{
		double acum = values[0] * weights[0];
		double weigthsAcum = weights[0];
		
		for(int i = 1; i < 9; i++)
		{
			acum += ((values[i] * weights[i]) + (values[i + 2] * weights[i + 2])) / 2;
			weigthsAcum += (weights[i] + weights[i + 2]) / 2;
			i++;
		}
		
		for(int i = 9; i < ivalue; i++)
		{
			acum += values[i] * weights[i];
			weigthsAcum += weights[i];
		}
		return acum/weigthsAcum;
	}
}
