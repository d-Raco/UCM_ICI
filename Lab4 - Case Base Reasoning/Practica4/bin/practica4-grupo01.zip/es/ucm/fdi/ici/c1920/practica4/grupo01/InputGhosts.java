package es.ucm.fdi.ici.c1920.practica4.grupo01;

import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

public class InputGhosts 
{
	private GhostsDescription queryDesc;
	
	public GhostsDescription getInput(GHOST gh, Game game)
	{
		queryDesc = new GhostsDescription();

		setMsPacMan(game);

        setGhosts(game, gh);
		
        setPossibleMoves(gh, game);
        
		return queryDesc;
	}
	

	private void setMsPacMan (Game game)
	{
		queryDesc.setMsPacManLastMove(game.getPacmanLastMoveMade());
		queryDesc.setMsPacManCoorX(game.getNodeXCood(game.getPacmanCurrentNodeIndex()));
		queryDesc.setMsPacManCoorY(game.getNodeYCood(game.getPacmanCurrentNodeIndex()));
	}
	
	private void setGhosts(Game game, GHOST ghost)
    {	
		queryDesc.setThisGhostNode(game.getGhostCurrentNodeIndex(ghost));
			
		for(GHOST ghostType : GHOST.values())
		{
			switch(ghostType.name())
			{
			case "BLINKY":
				queryDesc.setDistanceGhost1(game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(ghostType)));
		        queryDesc.setEdibleGhost1(game.getGhostEdibleTime(ghostType));
		        queryDesc.setLastMoveGhost1(game.getGhostLastMoveMade(ghostType));
		        
		        if(game.getGhostLairTime(ghost) == 0)
            	{
	        		queryDesc.setCoorXGhost1(game.getNodeXCood(game.getGhostCurrentNodeIndex(ghostType)));
	        		queryDesc.setCoorYGhost1(game.getNodeYCood(game.getGhostCurrentNodeIndex(ghostType)));
	        		
	        		queryDesc.setClosestPillsGhost1(setPill(game, game.getGhostCurrentNodeIndex(ghostType)));
	        		queryDesc.setClosestPowerPillGhost1(setPowerPill(game, game.getGhostCurrentNodeIndex(ghostType)));
            	}
		        else
            	{
		        	queryDesc.setCoorXGhost1(game.getNodeXCood(game.getGhostInitialNodeIndex()));
	        		queryDesc.setCoorYGhost1(game.getNodeYCood(game.getGhostInitialNodeIndex()));
	        		
	        		queryDesc.setClosestPillsGhost1(setPill(game, game.getGhostInitialNodeIndex()));
	        		queryDesc.setClosestPowerPillGhost1(setPowerPill(game, game.getGhostInitialNodeIndex()));
            	}
	        	
		        break;
	        
			case "PINKY":
				queryDesc.setDistanceGhost2(game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(ghostType)));
		        queryDesc.setEdibleGhost2(game.getGhostEdibleTime(ghostType));
		        queryDesc.setLastMoveGhost2(game.getGhostLastMoveMade(ghostType));
		        
		        if(game.getGhostLairTime(ghost) == 0)
            	{
	        		queryDesc.setCoorXGhost1(game.getNodeXCood(game.getGhostCurrentNodeIndex(ghostType)));
	        		queryDesc.setCoorYGhost1(game.getNodeYCood(game.getGhostCurrentNodeIndex(ghostType)));
	        		
	        		queryDesc.setClosestPillsGhost1(setPill(game, game.getGhostCurrentNodeIndex(ghostType)));
	        		queryDesc.setClosestPowerPillGhost1(setPowerPill(game, game.getGhostCurrentNodeIndex(ghostType)));
            	}
		        else
            	{
		        	queryDesc.setCoorXGhost1(game.getNodeXCood(game.getGhostInitialNodeIndex()));
	        		queryDesc.setCoorYGhost1(game.getNodeYCood(game.getGhostInitialNodeIndex()));
	        		
	        		queryDesc.setClosestPillsGhost1(setPill(game, game.getGhostInitialNodeIndex()));
	        		queryDesc.setClosestPowerPillGhost1(setPowerPill(game, game.getGhostInitialNodeIndex()));
            	}
	        	
		        break;
	        
			case "INKY":
				queryDesc.setDistanceGhost3(game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(ghostType)));
		        queryDesc.setEdibleGhost3(game.getGhostEdibleTime(ghostType));
		        queryDesc.setLastMoveGhost3(game.getGhostLastMoveMade(ghostType));
		       
		        if(game.getGhostLairTime(ghost) == 0)
            	{
	        		queryDesc.setCoorXGhost1(game.getNodeXCood(game.getGhostCurrentNodeIndex(ghostType)));
	        		queryDesc.setCoorYGhost1(game.getNodeYCood(game.getGhostCurrentNodeIndex(ghostType)));
	        		
	        		queryDesc.setClosestPillsGhost1(setPill(game, game.getGhostCurrentNodeIndex(ghostType)));
	        		queryDesc.setClosestPowerPillGhost1(setPowerPill(game, game.getGhostCurrentNodeIndex(ghostType)));
            	}
		        else
            	{
		        	queryDesc.setCoorXGhost1(game.getNodeXCood(game.getGhostInitialNodeIndex()));
	        		queryDesc.setCoorYGhost1(game.getNodeYCood(game.getGhostInitialNodeIndex()));
	        		
	        		queryDesc.setClosestPillsGhost1(setPill(game, game.getGhostInitialNodeIndex()));
	        		queryDesc.setClosestPowerPillGhost1(setPowerPill(game, game.getGhostInitialNodeIndex()));
            	}
	        	
		        break;
	        
		    default:
		    	queryDesc.setDistanceGhost4(game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(ghostType)));
		        queryDesc.setEdibleGhost4(game.getGhostEdibleTime(ghostType));
		        queryDesc.setLastMoveGhost4(game.getGhostLastMoveMade(ghostType));
		        
		        if(game.getGhostLairTime(ghost) == 0)
            	{
	        		queryDesc.setCoorXGhost1(game.getNodeXCood(game.getGhostCurrentNodeIndex(ghostType)));
	        		queryDesc.setCoorYGhost1(game.getNodeYCood(game.getGhostCurrentNodeIndex(ghostType)));
	        		
	        		queryDesc.setClosestPillsGhost1(setPill(game, game.getGhostCurrentNodeIndex(ghostType)));
	        		queryDesc.setClosestPowerPillGhost1(setPowerPill(game, game.getGhostCurrentNodeIndex(ghostType)));
            	}
		        else
            	{
		        	queryDesc.setCoorXGhost1(game.getNodeXCood(game.getGhostInitialNodeIndex()));
	        		queryDesc.setCoorYGhost1(game.getNodeYCood(game.getGhostInitialNodeIndex()));
	        		
	        		queryDesc.setClosestPillsGhost1(setPill(game, game.getGhostInitialNodeIndex()));
	        		queryDesc.setClosestPowerPillGhost1(setPowerPill(game, game.getGhostInitialNodeIndex()));
            	}
			}
		}	   
	}
   
	private void setPossibleMoves(GHOST gh, Game game)
	{
		MOVE[] possibleMoves = game.getPossibleMoves(game.getGhostCurrentNodeIndex(gh), game.getGhostLastMoveMade(gh));
		
		boolean right = false, 
				top = false, 
				left = false, 
				bottom = false;
		
		for(MOVE m : possibleMoves)
			switch(m)
			{
				case RIGHT:
					right = true;
					break;
					
				case UP:
					top = true;
					break;
					
				case LEFT:
					left = true;
					break;
					
				case DOWN:
					bottom = true;
					break;
			}
		
		queryDesc.setRightMove(right);
		queryDesc.setTopMove(top);
		queryDesc.setLeftMove(left);
		queryDesc.setDownMove(bottom);
	}
	
	private int setPill(Game game, int node) 
	{
        int[] pills = game.getActivePillsIndices();
        
        int pill = -1;
        
        double min_distance = Double.MAX_VALUE;
	
		for(int index : pills) 
		{
			double distance = game.getShortestPathDistance(node, index);
			if(distance <= min_distance) 
			{
				pill = index;
				
				min_distance = distance;
			}
		}
		
		return pill;
	}

    private int setPowerPill (Game game, int node)
    {
    	int[] powerPills = game.getActivePowerPillsIndices();
    	
    	int powerPill = -1;
    	
    	double min_distance = Double.MAX_VALUE;
    	
    	for(int index : powerPills)
    	{
    		double distance = game.getShortestPathDistance(node, index);
    		if(distance <= min_distance)
    		{
    			powerPill = index;
    			min_distance = distance;
    		}
    	}
    	
    	return powerPill;
    }
   
}
