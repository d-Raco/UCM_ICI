package es.ucm.fdi.ici.c1920.practica4.grupo01;

import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import pacman.game.Game;

public class InputMsPacMan 
{
	private MsPacManDescription queryDesc;
	
	public MsPacManDescription getInput(Game game)
	{
		queryDesc = new MsPacManDescription();
        
		setMsPacMan(game);
        
        setGhosts(game);
        
        setPossibleMoves(game);
		
        setPills(game);
        
        setPowerPill(game);
        
        return queryDesc;
	}
	
	private void setMsPacMan (Game game)
	{
		queryDesc.setMsPacManLastMove(game.getPacmanLastMoveMade());
		queryDesc.setMsPacManNode(game.getPacmanCurrentNodeIndex());
	}
	
	private void setGhosts(Game game)
    {
        for (GHOST ghost : GHOST.values()) 
        { 
            switch(ghost.name())
            {
	            case "BLINKY":
	            	queryDesc.setBlinkyDistance(game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(ghost)));
	            	queryDesc.setBlinkyEdible(game.getGhostEdibleTime(ghost) > 1);
	            	queryDesc.setBlinkyLastMove(game.getGhostLastMoveMade(ghost));
	            	
	            	if(game.getGhostLairTime(ghost) == 0)
	            	{
	            		queryDesc.setBlinkyCoorX(game.getNodeXCood(game.getGhostCurrentNodeIndex(ghost)));
	            		queryDesc.setBlinkyCoorY(game.getNodeYCood(game.getGhostCurrentNodeIndex(ghost)));
	            	}
	            	else
	            	{
	            		queryDesc.setBlinkyCoorX(game.getNodeXCood(game.getGhostInitialNodeIndex()));
	            		queryDesc.setBlinkyCoorY(game.getNodeYCood(game.getGhostInitialNodeIndex()));
	            	}
	            	
	            	break;
	            	
	            case "PINKY":
	            	queryDesc.setPinkyDistance(game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(ghost)));
	            	queryDesc.setPinkyEdible(game.getGhostEdibleTime(ghost) > 1);
	            	queryDesc.setPinkyLastMove(game.getGhostLastMoveMade(ghost));
	            	
	            	if(game.getGhostLairTime(ghost) == 0)
	            	{
	            		queryDesc.setPinkyCoorX(game.getNodeXCood(game.getGhostCurrentNodeIndex(ghost)));
	            		queryDesc.setPinkyCoorY(game.getNodeYCood(game.getGhostCurrentNodeIndex(ghost)));
	            	}
	            	else
	            	{
	            		queryDesc.setPinkyCoorX(game.getNodeXCood(game.getGhostInitialNodeIndex()));
	            		queryDesc.setPinkyCoorY(game.getNodeYCood(game.getGhostInitialNodeIndex()));
	            	}
	            		
	            	break;
	            	
	            case "INKY":
	            	queryDesc.setInkyDistance(game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(ghost)));
	            	queryDesc.setInkyEdible(game.getGhostEdibleTime(ghost) > 1);
	            	queryDesc.setInkyLastMove(game.getGhostLastMoveMade(ghost));
	            	
	            	if(game.getGhostLairTime(ghost) == 0)
	            	{
	            		queryDesc.setInkyCoorX(game.getNodeXCood(game.getGhostCurrentNodeIndex(ghost)));
	            		queryDesc.setInkyCoorY(game.getNodeYCood(game.getGhostCurrentNodeIndex(ghost)));
	            	}
	            	else
	            	{
	            		queryDesc.setInkyCoorX(game.getNodeXCood(game.getGhostInitialNodeIndex()));
	            		queryDesc.setInkyCoorY(game.getNodeYCood(game.getGhostInitialNodeIndex()));
	            	}
	            		
	            	break;
	            	
	            case "SUE":
	            	queryDesc.setSueDistance(game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), game.getGhostCurrentNodeIndex(ghost)));
	            	queryDesc.setSueEdible(game.getGhostEdibleTime(ghost) > 1);
	            	queryDesc.setSueLastMove(game.getGhostLastMoveMade(ghost));
	            	
	            	if(game.getGhostLairTime(ghost) == 0)
	            	{
	            		queryDesc.setSueCoorX(game.getNodeXCood(game.getGhostCurrentNodeIndex(ghost)));
	            		queryDesc.setSueCoorY(game.getNodeYCood(game.getGhostCurrentNodeIndex(ghost)));
	            	}
	            	else
	            	{
	            		queryDesc.setSueCoorX(game.getNodeXCood(game.getGhostInitialNodeIndex()));
	            		queryDesc.setSueCoorY(game.getNodeYCood(game.getGhostInitialNodeIndex()));
	            	}
	            		
	            	break;
            }
        }
    }
	
	private void setPossibleMoves(Game game)
	{
		MOVE[] possibleMoves = game.getPossibleMoves(game.getPacmanCurrentNodeIndex(), game.getPacmanLastMoveMade());
		
		boolean right = false, 
				top = false, 
				left = false, 
				bottom = false;
		
		for(MOVE m : possibleMoves)
			switch(m)
			{
				case RIGHT:
					right = true;
					break;
					
				case UP:
					top = true;
					break;
					
				case LEFT:
					left = true;
					break;
					
				case DOWN:
					bottom = true;
					break;
			}
		
		queryDesc.setRightMove(right);
		queryDesc.setTopMove(top);
		queryDesc.setLeftMove(left);
		queryDesc.setDownMove(bottom);
	}
	
    private void setPills(Game game) 
	{
        int[] pills = game.getActivePillsIndices();
        
        int pill1 = -1, pill2 = -1, pill3 = -1, pill4 = -1;
        
        double min_distance1 = Double.MAX_VALUE,
        		min_distance2 = Double.MAX_VALUE,
        		min_distance3 = Double.MAX_VALUE,
        		min_distance4 = Double.MAX_VALUE;
	
		for(int index : pills) 
		{
			double distance = game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), index);
			if(distance <= min_distance1) 
			{
				pill4 = pill3;
				pill3 = pill2;
				pill2 = pill1;
				pill1 = index;
				
				min_distance1 = distance;
			}
			else if(distance <= min_distance2)
			{
				pill4 = pill3;
				pill3 = pill2;
				pill2 = index;
				
				min_distance2 = distance;
				
			}
			else if(distance <= min_distance3)
			{
				pill4 = pill3;
				pill3 = index;
				
				min_distance3 = distance;
			}
			else if(distance <= min_distance4)
			{
				pill4 = index;
				
				min_distance4 = distance;
			}
		}
		
		queryDesc.setClosestPills1(pill1);
		queryDesc.setClosestPills2(pill2);
		queryDesc.setClosestPills3(pill3);
		queryDesc.setClosestPills4(pill4);
	}

    private void setPowerPill (Game game)
    {
    	int[] powerPills = game.getActivePowerPillsIndices();
    	
    	int powerPill = -1;
    	
    	double min_distance = Double.MAX_VALUE;
    	
    	for(int index : powerPills)
    	{
    		double distance = game.getShortestPathDistance(game.getPacmanCurrentNodeIndex(), index);
    		if(distance <= min_distance)
    		{
    			powerPill = index;
    			min_distance = distance;
    		}
    	}
    	
    	queryDesc.setClosestPowerPill(powerPill);
    }
    
}
