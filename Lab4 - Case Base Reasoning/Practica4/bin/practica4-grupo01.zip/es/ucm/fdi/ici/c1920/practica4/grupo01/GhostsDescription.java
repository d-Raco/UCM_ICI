package es.ucm.fdi.ici.c1920.practica4.grupo01;

import es.ucm.fdi.ici.c1920.practica4.grupo01.Constants.CASE_TYPE;
import pacman.game.Constants.MOVE;
import ucm.gaia.jcolibri.cbrcore.Attribute;

public class GhostsDescription implements ucm.gaia.jcolibri.cbrcore.CaseComponent
{
	String id;
	
	CASE_TYPE type;
	
	Integer thisGhostNode;
	Integer msPacManCoorX, msPacManCoorY;	
	//le he dado muchas vueltas a esto de clacular las permutaciones de los fantasmas para escoger el que mayor similitud tenga, pero me he encontrado con demasiados problemas.
	Integer coorXGhost1,coorYGhost1, coorXGhost2,coorYGhost2, coorXGhost3,coorYGhost3, coorXGhost4, coorYGhost4;
	MOVE msPacManLastMove;
	MOVE lastMoveGhost1, lastMoveGhost2, lastMoveGhost3, lastMoveGhost4;
	Integer distanceGhost1, distanceGhost2, distanceGhost3, distanceGhost4;
	Integer timeGhost1, timeGhost2, timeGhost3, timeGhost4;
	Boolean topMove, leftMove, downMove, rightMove;
	Integer closestPillsGhost1, closestPillsGhost2, closestPillsGhost3, closestPillsGhost4;
	Integer closestPowerPillGhost1, closestPowerPillGhost2, closestPowerPillGhost3, closestPowerPillGhost4;
	
	public Attribute getIdAttribute()
	{
		return new Attribute("id", MsPacManDescription.class);
	}
	
	public void setId(String i) {id = i;}
	
	public CASE_TYPE getCaseType() { return type; }
	public void setCaseType(CASE_TYPE n) { type = n; }
	
	public Integer getThisGhostNode() { return thisGhostNode; }
	public void setThisGhostNode (Integer n) { thisGhostNode = n; }
	
	public Integer getMsPacManCoorX() { return msPacManCoorX; }
	public void setMsPacManCoorX(Integer n) { msPacManCoorX = n; }
	
	public Integer getMsPacManCoorY() { return msPacManCoorY; }
	public void setMsPacManCoorY(Integer n) { msPacManCoorY = n; }

	public Integer getCoorXGhost1() { return coorXGhost1; }
	public void setCoorXGhost1(Integer n) { coorXGhost1 = n; }
	
	public Integer getCoorXGhost2() { return coorXGhost2; }
	public void setCoorXGhost2(Integer n) { coorXGhost2 = n; }
	
	public Integer getCoorXGhost3() { return coorXGhost3; }
	public void setCoorXGhost3(Integer n) { coorXGhost3 = n; }
	
	public Integer getCoorXGhost4() { return coorXGhost4; }
	public void setCoorXGhost4(Integer n) { coorXGhost4 = n; }

	public Integer getCoorYGhost1() { return coorYGhost1; }
	public void setCoorYGhost1(Integer n) { coorYGhost1 = n; }
	
	public Integer getCoorYGhost2() { return coorYGhost2; }
	public void setCoorYGhost2(Integer n) { coorYGhost2 = n; }
	
	public Integer getCoorYGhost3() { return coorYGhost3; }
	public void setCoorYGhost3(Integer n) { coorYGhost3 = n; }
	
	public Integer getCoorYGhost4() { return coorYGhost4; }
	public void setCoorYGhost4(Integer n) { coorYGhost4 = n; }

	public MOVE getMsPacManLastMove() { return msPacManLastMove; }
	public void setMsPacManLastMove(MOVE n) { msPacManLastMove = n; }

	public MOVE getLastMoveGhost1() { return lastMoveGhost1; }
	public void setLastMoveGhost1(MOVE n) { lastMoveGhost1 = n; }
	
	public MOVE getLastMoveGhost2() { return lastMoveGhost2; }
	public void setLastMoveGhost2(MOVE n) { lastMoveGhost2 = n; }
	
	public MOVE getLastMoveGhost3() { return lastMoveGhost3; }
	public void setLastMoveGhost3(MOVE n) { lastMoveGhost3 = n; }
	
	public MOVE getLastMoveGhost4() { return lastMoveGhost4; }
	public void setLastMoveGhost4(MOVE n) { lastMoveGhost4 = n; }

	public Integer getDistanceGhost1() { return distanceGhost1; }
	public void setDistanceGhost1(Integer n) { distanceGhost1 = n; }
	
	public Integer getDistanceGhost2() { return distanceGhost2; }
	public void setDistanceGhost2(Integer n) { distanceGhost2 = n; }
	
	public Integer getDistanceGhost3() { return distanceGhost3; }
	public void setDistanceGhost3(Integer n) { distanceGhost3 = n; }
	
	public Integer getDistanceGhost4() { return distanceGhost4; }
	public void setDistanceGhost4(Integer n) { distanceGhost4 = n; }

	public Integer getEdibleGhost1() { return timeGhost1; }
	public void setEdibleGhost1(Integer n) { timeGhost1 = n; }
	
	public Integer getEdibleGhost2() { return timeGhost2; }
	public void setEdibleGhost2(Integer n) { timeGhost2 = n; }
	
	public Integer getEdibleGhost3() { return timeGhost3; }
	public void setEdibleGhost3(Integer n) { timeGhost3 = n; }
	
	public Integer getEdibleGhost4() { return timeGhost4; }
	public void setEdibleGhost4(Integer n) { timeGhost4 = n; }
	
	public Boolean getTopMove() { return topMove; }
	public void setTopMove(Boolean n) { topMove = n; }
	
	public Boolean getLeftMove() { return leftMove; }
	public void setLeftMove(Boolean n) { leftMove = n; }
	
	public Boolean getDownMove() { return downMove; }
	public void setDownMove(Boolean n) { downMove = n; }
	
	public Boolean getRightMove() { return rightMove; }
	public void setRightMove(Boolean n) { rightMove = n; }

	public Integer getClosestPillsGhost1() { return closestPillsGhost1; }
	public void setClosestPillsGhost1(Integer n) { closestPillsGhost1 = n; }
	
	public Integer getClosestPillsGhost2() { return closestPillsGhost2; }
	public void setClosestPillsGhost2(Integer n) { closestPillsGhost2 = n; }
	
	public Integer getClosestPillsGhost3() { return closestPillsGhost3; }
	public void setClosestPillsGhost3(Integer n) { closestPillsGhost3 = n; }
	
	public Integer getClosestPillsGhost4() { return closestPillsGhost4; }
	public void setClosestPillsGhost4(Integer n) { closestPillsGhost4 = n; }

	public Integer getClosestPowerPillGhost1() { return closestPowerPillGhost1; }
	public void setClosestPowerPillGhost1(Integer n) { closestPowerPillGhost1 = n; }
	
	public Integer getClosestPowerPillGhost2() { return closestPowerPillGhost2; }
	public void setClosestPowerPillGhost2(Integer n) { closestPowerPillGhost2 = n; }
	
	public Integer getClosestPowerPillGhost3() { return closestPowerPillGhost3; }
	public void setClosestPowerPillGhost3(Integer n) { closestPowerPillGhost3 = n; }
	
	public Integer getClosestPowerPillGhost4() { return closestPowerPillGhost4; }
	public void setClosestPowerPillGhost4(Integer n) { closestPowerPillGhost4 = n; }
}
