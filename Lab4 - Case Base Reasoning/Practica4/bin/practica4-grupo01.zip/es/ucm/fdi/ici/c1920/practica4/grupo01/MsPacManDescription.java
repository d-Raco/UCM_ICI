package es.ucm.fdi.ici.c1920.practica4.grupo01;

import ucm.gaia.jcolibri.cbrcore.Attribute;
import es.ucm.fdi.ici.c1920.practica4.grupo01.Constants.CASE_TYPE;
import pacman.game.Constants.MOVE;

public class MsPacManDescription implements ucm.gaia.jcolibri.cbrcore.CaseComponent
{
	String id; 
	
	CASE_TYPE type;
	
	Integer msPacManNode;
	Integer blinkyCoorX, blinkyCoorY;
	Integer pinkyCoorX,pinkyCoorY;
	Integer inkyCoorX,inkyCoorY;
	Integer sueCoorX, sueCoorY;
	MOVE msPacManLastMove;
	MOVE blinkyLastMove, pinkyLastMove, inkyLastMove, sueLastMove;
	Integer blinkyDistance, pinkyDistance, inkyDistance, sueDistance;
	Boolean blinkyEdible, pinkyEdible, inkyEdible, sueEdible;
	Boolean topMove, leftMove, downMove, rightMove;
	Integer closestPills1, closestPills2, closestPills3, closestPills4;
	Integer closestPowerPill;
	
	public Attribute getIdAttribute()
	{
		return new Attribute("id", MsPacManDescription.class);
	}
	
	public void setId(String i) {id = i;}
	
	public CASE_TYPE getCaseType() { return type; }
	public void setCaseType(CASE_TYPE n) { type = n; }
	
	public Integer getMsPacManNode() { return msPacManNode; }
	public void setMsPacManNode(Integer n) { msPacManNode = n; }
	
	public Integer getBlinkyCoorX() { return blinkyCoorX; }
	public void setBlinkyCoorX(Integer n) { blinkyCoorX = n; }
	
	public Integer getPinkyCoorX() { return pinkyCoorX; }
	public void setPinkyCoorX(Integer n) { pinkyCoorX = n; }
	
	public Integer getInkyCoorX() { return inkyCoorX; }
	public void setInkyCoorX(Integer n) { inkyCoorX = n; }
	
	public Integer getSueCoorX() { return sueCoorX; }
	public void setSueCoorX(Integer n) { sueCoorX = n; }
	

	public Integer getBlinkyCoorY() { return blinkyCoorY; }
	public void setBlinkyCoorY (Integer n) { blinkyCoorY = n; }
	
	public Integer getPinkyCoorY() { return pinkyCoorY; }
	public void setPinkyCoorY(Integer n) { pinkyCoorY = n; }
	
	public Integer getInkyCoorY() { return inkyCoorY; }
	public void setInkyCoorY(Integer n) { inkyCoorY = n; }
	
	public Integer getSueCoorY() { return sueCoorY; }
	public void setSueCoorY(Integer n) { sueCoorY = n; }
	
	
	public MOVE getMsPacManLastMove() { return msPacManLastMove; }
	public void setMsPacManLastMove(MOVE n) { msPacManLastMove = n; }

	public MOVE getBlinkyLastMove() { return blinkyLastMove; }
	public void setBlinkyLastMove(MOVE n) { blinkyLastMove = n; }
	
	public MOVE getPinkyLastMove() { return pinkyLastMove; }
	public void setPinkyLastMove(MOVE n) { pinkyLastMove = n; }
	
	public MOVE getInkyLastMove() { return inkyLastMove; }
	public void setInkyLastMove(MOVE n) { inkyLastMove = n; }
	
	public MOVE getSueLastMove() { return sueLastMove; }
	public void setSueLastMove(MOVE n) { sueLastMove = n; }
	

	public Integer getBlinkyDistance() { return blinkyDistance; }
	public void setBlinkyDistance(Integer n) { blinkyDistance = n; }
	
	public Integer getPinkyDistance() { return pinkyDistance; }
	public void setPinkyDistance(Integer n) { pinkyDistance = n; }
	
	public Integer getInkyDistance() { return inkyDistance; }
	public void setInkyDistance(Integer n) { inkyDistance = n; }
	
	public Integer getSueDistance() { return sueDistance; }
	public void setSueDistance(Integer n) { sueDistance = n; }
	

	public Boolean getTopMove() { return topMove; }
	public void setTopMove(Boolean n) { topMove = n; }
	
	public Boolean getLeftMove() { return leftMove; }
	public void setLeftMove(Boolean n) { leftMove = n; }
	
	public Boolean getDownMove() { return downMove; }
	public void setDownMove(Boolean n) { downMove = n; }
	
	public Boolean getRightMove() { return rightMove; }
	public void setRightMove(Boolean n) { rightMove = n; }
	
	
	public Boolean getBlinkyEdible() { return blinkyEdible; }
	public void setBlinkyEdible(Boolean n) { blinkyEdible = n; }
	
	public Boolean getPinkyEdible() { return pinkyEdible; }
	public void setPinkyEdible(Boolean n) { pinkyEdible = n; }
	
	public Boolean getInkyEdible() { return inkyEdible; }
	public void setInkyEdible(Boolean n) { inkyEdible = n; }
	
	public Boolean getSueEdible() { return sueEdible; }
	public void setSueEdible(Boolean n) { sueEdible = n; }
	

	public Integer getClosestPills1() { return closestPills1; }
	public void setClosestPills1(Integer n) { closestPills1 = n; }
	
	public Integer getClosestPills2() { return closestPills2; }
	public void setClosestPills2(Integer n) { closestPills2 = n; }
	
	public Integer getClosestPills3() { return closestPills3; }
	public void setClosestPills3(Integer n) { closestPills3 = n; }
	
	public Integer getClosestPills4() { return closestPills4; }
	public void setClosestPills4(Integer n) { closestPills4 = n; }

	public Integer getClosestPowerPill() { return closestPowerPill; }
	public void setClosestPowerPill(Integer n) { closestPowerPill = n; }
}
