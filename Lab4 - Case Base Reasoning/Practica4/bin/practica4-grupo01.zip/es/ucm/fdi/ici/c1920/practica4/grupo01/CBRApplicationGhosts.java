package es.ucm.fdi.ici.c1920.practica4.grupo01;

import ucm.gaia.jcolibri.cbrcore.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.Random;
import java.util.Vector;

import es.ucm.fdi.ici.c1920.practica4.grupo01.Constants.CASE_TYPE;
import pacman.game.Game;
import pacman.game.Constants.GHOST;
import pacman.game.Constants.MOVE;
import ucm.gaia.jcolibri.casebase.LinealCaseBase;
import ucm.gaia.jcolibri.cbraplications.StandardCBRApplication;
import ucm.gaia.jcolibri.connector.DataBaseConnector;
import ucm.gaia.jcolibri.connector.PlainTextConnector;
import ucm.gaia.jcolibri.exception.ExecutionException;
import ucm.gaia.jcolibri.method.retrieve.RetrievalResult;
import ucm.gaia.jcolibri.method.retrieve.NNretrieval.NNConfig;
import ucm.gaia.jcolibri.method.retrieve.NNretrieval.NNScoringMethod;
import ucm.gaia.jcolibri.method.retrieve.NNretrieval.similarity.global.Average;
import ucm.gaia.jcolibri.method.retrieve.NNretrieval.similarity.local.Equal;
import ucm.gaia.jcolibri.method.retrieve.NNretrieval.similarity.local.Interval;
import ucm.gaia.jcolibri.method.retrieve.selection.SelectCases;
import ucm.gaia.jcolibri.util.FileIO;

public class CBRApplicationGhosts implements StandardCBRApplication
{
	private Vector<CBRCase> _buffer = new Vector<CBRCase>();
	private Collection<CBRCase> _casesToLearn = new ArrayList<CBRCase>();;
	private Random _rnd = new Random();

	private Ghosts _Ghosts;
	private GHOST ghost;
	
	public CBRApplicationGhosts(Ghosts g)
	{
		_Ghosts = g;
	}
	public void setGhost(GHOST g)
	{
		ghost = g;
	}

	private Game _game;
	public void setGame(Game g) { _game = g; }

	
	private Connector _connector;
	private CBRCaseBase _caseBase;
	
	public void configure() throws ExecutionException
	{
		try
		{
			_connector = new PlainTextConnector();
			_connector.initFromXMLfile(FileIO.findFile("src/es/ucm/fdi/ici/c1920/practica4/grupo01/data/GhostsTextConnector.xml"));
			_caseBase = new LinealCaseBase();
			
		} 
		catch(Exception e)
		{
			throw new ExecutionException(e);
		}
	}
	
	private Collection<CBRCase> _chasingCases = new ArrayList<CBRCase>();
	private Collection<CBRCase> _runawayCases = new ArrayList<CBRCase>();
	
	public CBRCaseBase preCycle() throws ExecutionException
	{
		_caseBase.init(_connector);
		java.util.Collection<CBRCase> cases = _caseBase.getCases();
		
		for(CBRCase c: cases)
		{
			System.out.println(c);
			
			GhostsDescription desc = (GhostsDescription) c.getDescription();
			if(desc.getCaseType() == CASE_TYPE.RUN)
				_runawayCases.add(c);
			else
				_chasingCases.add(c);
		}
		return _caseBase;
	}
	
	public void cycle(CBRQuery query) throws ExecutionException
	{
		NNConfig simConfig = new NNConfig();
		
		simConfig.setDescriptionSimFunction(new GhostsGlobalSimilarityFunction());

		Attribute thisGhostNode = new Attribute("thisGhostNode", GhostsDescription.class);
		simConfig.addMapping(thisGhostNode, new Equal());
		simConfig.setWeight(thisGhostNode, 2.0);
		
		Attribute msPacManCoorX = new Attribute("msPacManCoorX", GhostsDescription.class);
		simConfig.addMapping(msPacManCoorX, new Interval(20));
		simConfig.setWeight(msPacManCoorX, 1.5);
		
		Attribute msPacManCoorY = new Attribute("msPacManCoorY", GhostsDescription.class);
		simConfig.addMapping(msPacManCoorY, new Interval(20));
		simConfig.setWeight(msPacManCoorY, 1.5);
		
		simConfig.addMapping(new Attribute("coorXGhost1", GhostsDescription.class), new Interval(20));
		simConfig.addMapping(new Attribute("coorYGhost1", GhostsDescription.class), new Interval(20));
		
		simConfig.addMapping(new Attribute("coorXGhost2", GhostsDescription.class), new Interval(20));
		simConfig.addMapping(new Attribute("coorYGhost2", GhostsDescription.class), new Interval(20));
		
		simConfig.addMapping(new Attribute("coorXGhost3", GhostsDescription.class), new Interval(20));
		simConfig.addMapping(new Attribute("coorYGhost3", GhostsDescription.class), new Interval(20));
		
		simConfig.addMapping(new Attribute("coorXGhost4", GhostsDescription.class), new Interval(20));
		simConfig.addMapping(new Attribute("coorYGhost4", GhostsDescription.class), new Interval(20));
		
		simConfig.addMapping(new Attribute("msPacManLastMove", GhostsDescription.class), new Equal());
		
		simConfig.addMapping(new Attribute("lastMoveGhost1", GhostsDescription.class), new Equal());		
		simConfig.addMapping(new Attribute("lastMoveGhost2", GhostsDescription.class), new Equal());
		simConfig.addMapping(new Attribute("lastMoveGhost3", GhostsDescription.class), new Equal());
		simConfig.addMapping(new Attribute("lastMoveGhost4", GhostsDescription.class), new Equal());
		
		simConfig.addMapping(new Attribute("distanceGhost1", GhostsDescription.class), new Interval(20));
		simConfig.addMapping(new Attribute("distanceGhost2", GhostsDescription.class), new Interval(20));
		simConfig.addMapping(new Attribute("distanceGhost3", GhostsDescription.class), new Interval(20));
		simConfig.addMapping(new Attribute("distanceGhost4", GhostsDescription.class), new Interval(20));
		
		simConfig.addMapping(new Attribute("timeGhost1", GhostsDescription.class), new Interval(5));
		simConfig.addMapping(new Attribute("timeGhost2", GhostsDescription.class), new Interval(5));
		simConfig.addMapping(new Attribute("timeGhost3", GhostsDescription.class), new Interval(5));
		simConfig.addMapping(new Attribute("timeGhost4", GhostsDescription.class), new Interval(5));
			
		Attribute topMove = new Attribute("topMove", GhostsDescription.class);
		simConfig.addMapping(topMove, new Equal());
		simConfig.setWeight(topMove, 1.5);
		
		Attribute leftMove = new Attribute("leftMove", GhostsDescription.class);
		simConfig.addMapping(leftMove, new Equal());
		simConfig.setWeight(leftMove, 1.5);
		
		Attribute downMove = new Attribute("downMove", GhostsDescription.class);
		simConfig.addMapping(downMove, new Equal());
		simConfig.setWeight(downMove, 1.5);
		
		Attribute rightMove = new Attribute("rightMove", GhostsDescription.class);
		simConfig.addMapping(rightMove, new Equal());
		simConfig.setWeight(rightMove, 1.5);
		
		Attribute ClosestPillsBlinky = new Attribute("closestPillsGhost1", GhostsDescription.class);
		simConfig.addMapping(ClosestPillsBlinky, new Equal());
		simConfig.setWeight(ClosestPillsBlinky, 0.1);
		
		Attribute ClosestPillsPinky = new Attribute("closestPillsGhost2", GhostsDescription.class);
		simConfig.addMapping(ClosestPillsPinky, new Equal());
		simConfig.setWeight(ClosestPillsPinky, 0.1);
		
		Attribute ClosestPillsInky = new Attribute("closestPillsGhost3", GhostsDescription.class);
		simConfig.addMapping(ClosestPillsInky, new Equal());
		simConfig.setWeight(ClosestPillsInky, 0.1);
		
		Attribute ClosestPillsSue = new Attribute("closestPillsGhost4", GhostsDescription.class);
		simConfig.addMapping(ClosestPillsSue, new Equal());
		simConfig.setWeight(ClosestPillsSue, 0.1);
		
		Attribute ClosestPowerPillBlinky = new Attribute("closestPowerPillGhost1", GhostsDescription.class);
		simConfig.addMapping(ClosestPowerPillBlinky, new Equal());
		simConfig.setWeight(ClosestPowerPillBlinky, 0.2);
		
		Attribute ClosestPowerPillPinky = new Attribute("closestPowerPillGhost2", GhostsDescription.class);
		simConfig.addMapping(ClosestPowerPillPinky, new Equal());
		simConfig.setWeight(ClosestPowerPillPinky, 0.2);
		
		Attribute ClosestPowerPillInky = new Attribute("closestPowerPillGhost3", GhostsDescription.class);
		simConfig.addMapping(ClosestPowerPillInky, new Equal());
		simConfig.setWeight(ClosestPowerPillInky, 0.2);
		
		Attribute ClosestPowerPillSue = new Attribute("closestPowerPillGhost4", GhostsDescription.class);
		simConfig.addMapping(ClosestPowerPillSue, new Equal());
		simConfig.setWeight(ClosestPowerPillSue, 0.2);
		
		Collection<RetrievalResult> eval;
		
		if(((GhostsDescription)query.getDescription()).getCaseType() == CASE_TYPE.RUN)
			eval = NNScoringMethod.evaluateSimilarity(_runawayCases, query, simConfig);
		else
			eval = NNScoringMethod.evaluateSimilarity(_chasingCases, query, simConfig);
		
		eval = SelectCases.selectTopKRR(eval, 5);
		
		Iterator<RetrievalResult> it = eval.iterator();
		RetrievalResult[] casos = new RetrievalResult[5];
		int i = 0;
		while(it.hasNext())
		{
			casos[i] = it.next(); 
			i++;
		}
		
		CBRCase newCase = new CBRCase();
		newCase.setDescription(query.getDescription());
		newCase.setSolution(new GhostsSolution());
		
		MOVE finalMove;
		if(casos[0] == null)
		{
			//movimiento random
			MOVE[] possibleMoves = _game.getPossibleMoves(_game.getGhostCurrentNodeIndex(ghost), _game.getGhostLastMoveMade(ghost));
			finalMove = possibleMoves[_rnd.nextInt(possibleMoves.length)];
		}
		else 
		{
			//movimiento solucion
			finalMove = chooseCaseMove(casos);
		}
		
		_Ghosts.setSolutions(finalMove);
		
		((GhostsSolution) newCase.getSolution()).setCaseType(((GhostsDescription)query.getDescription()).getCaseType());
		((GhostsSolution) newCase.getSolution()).setMsPacManDead(false);
		((GhostsSolution) newCase.getSolution()).setEvaluation(0);
		((GhostsSolution) newCase.getSolution()).setMsPacManTotalPoints(0);
		((GhostsSolution) newCase.getSolution()).setMoveMade(finalMove);
		
		_buffer.add(newCase);
	}
	
	private MOVE chooseCaseMove(RetrievalResult[] casos)
	{
		int top = 0,
			left = 0,
			bottom = 0,
			right = 0;
		
		MOVE move = null;
		
		int size = casos.length;
		for(int i = 0; i < size; i++)
		{
			GhostsSolution c = (GhostsSolution) casos[i].get_case().getSolution();
			if(c.getEvaluation() >= 25)
			{
				switch(c.getMoveMade())
				{
					case RIGHT:
						right += c.getEvaluation();
						break;
					case UP:
						top += c.getEvaluation();
						break;
					case LEFT:
						left += c.getEvaluation();
						break;
					case DOWN:
						bottom += c.getEvaluation();
						break;
				}
			}
		}
		
		if(top >= left && top >= bottom && top >= right)
			move = MOVE.UP;
		else if (left >= top && left >= bottom && left >= right)
			move = MOVE.LEFT;
		else if(bottom >= top && bottom >= left && bottom >= right)
			move = MOVE.DOWN;
		else if(right >= top && right >= left && right >= bottom)
			move = MOVE.RIGHT;
		
		return move;
	}
	
	public void updateBuffer(int points)
	{
		for(CBRCase c : _buffer)
		{
			int newPoints = ((GhostsSolution) c.getSolution()).getMsPacManTotalPoints();
			newPoints += points;
			
			((GhostsSolution) c.getSolution()).setMsPacManTotalPoints(newPoints);
			
			float evaluation = ((GhostsSolution) c.getSolution()).getEvaluation();

			if(evaluation - points / 10 >= -100)
				evaluation -= points / 10;
			else
				evaluation = -100;
			
			((GhostsSolution) c.getSolution()).setEvaluation(evaluation);
		}
		
		if(_buffer.size() > 10)
		{
			CBRCase c = _buffer.elementAt(0);
				
			removeCaseFromBuffer(c);
		}
	}
	
	public void MsPacManDead(int points)
	{
		int size = _buffer.size();
		for(int i = 0; i< size; i++)
		{
			CBRCase c = _buffer.elementAt(i);
			int newPoints = ((GhostsSolution) c.getSolution()).getMsPacManTotalPoints();
			newPoints += points;
			
			((GhostsSolution) c.getSolution()).setMsPacManTotalPoints(newPoints);
			
			float evaluation = ((GhostsSolution) c.getSolution()).getEvaluation();

			if(evaluation - points / 10 >= -100)
				evaluation -= points / 10;
			else
				evaluation = -100;
			
			if(evaluation + 100 <= 100)
				evaluation += 100;
			else
				evaluation = 100;
			
			((GhostsSolution) c.getSolution()).setEvaluation(evaluation);
			
			learnCase(c);
		}
		
		_buffer.clear();
	}
	
	public void removeCaseFromBuffer(CBRCase c)
	{
		learnCase(c);
		_buffer.remove(c);
	}
	
	public void learnCase(CBRCase c)
	{
		_casesToLearn.add(c);
	}
	
	public void postCycle() throws ExecutionException
	{
		_caseBase.learnCases(_casesToLearn);
		this._caseBase.close();
	}
}
